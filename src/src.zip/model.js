export const columns = [
  { id: 'backlog', label: 'backlog' },
  { id: 'todo', label: 'todo' },
  { id: 'in-progress', label: 'inProgress' },
  { id: 'qa', label: 'qa' },
  { id: 'done', label: 'done' },
];

const initialData = [
  {
    id: 'ASH-101',
    title: 'Architect database schema for Sprint workflow',
    description: 'Support multi-tenant projects and task transitions.',
    type: 'task',
    status: 'in-progress',
    priority: 'High',
    dueDate: '2026-11-20',
    tests: [
      { id: 't-1', title: 'Foreign key constraints prevent orphaned cards', passed: true },
      { id: 't-2', title: 'Migration script runs cleanly without rollback error', passed: false },
    ],
  },
  {
    id: 'ASH-102',
    title: 'JWT Token expiration silent renewal issue',
    description: 'Mobile clients get 401 when background app refreshes.',
    type: 'bug',
    status: 'qa',
    priority: 'High',
    dueDate: '2026-11-10',
    tests: [
      { id: 't-3', title: 'Refresh token endpoint issues valid new bearer', passed: true },
      { id: 't-4', title: 'Concurrency lock works under 10 parallel calls', passed: false },
    ],
  },
  {
    id: 'ASH-103',
    title: 'Dark Mode contrast adjustments for QA Column',
    description: 'Ensure text meets WCAG AA standards in low-light environments.',
    type: 'task',
    status: 'done',
    priority: 'Medium',
    dueDate: '2026-11-04',
    tests: [
      { id: 't-5', title: 'Color contrast ratio exceeds 4.5:1', passed: true },
    ],
  },
];

export function createTicket(status = 'backlog', type = 'task') {
  return {
    id: `ASH-${Math.floor(100 + Math.random() * 900)}`,
    title: '',
    description: '',
    type,
    status,
    priority: 'Medium',
    dueDate: '',
    tests: [],
  };
}

export function loadTickets() {
  try {
    const saved = JSON.parse(localStorage.getItem('ashkan-board-tickets'));
    if (!Array.isArray(saved) || saved.length === 0) return initialData;
    return saved.map((t) => ({
      ...t,
      tests: Array.isArray(t.tests) ? t.tests : [],
    }));
  } catch {
    return initialData;
  }
}

export function canMoveToDone(task) {
  // Hard Quality Gate: At least one test case must exist and 100% must be checked
  return task.tests.length > 0 && task.tests.every((test) => test.passed);
}

export function checkIsOverdue(task) {
  if (!task.dueDate || task.status === 'done') return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return new Date(`${task.dueDate}T00:00:00`) < today;
}
