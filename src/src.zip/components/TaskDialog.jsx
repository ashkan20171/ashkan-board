import { useState } from 'react';
import { Plus, Trash2, X } from 'lucide-react';
import { useLanguage } from '../i18n';

export default function TaskDialog({
  task,
  isExisting,
  onClose,
  onSave,
  onDelete,
}) {
  const { t } = useLanguage();
  const [title, setTitle] = useState(task.title || '');
  const [description, setDescription] = useState(task.description || '');
  const [priority, setPriority] = useState(task.priority || 'Medium');
  const [type, setType] = useState(task.type || 'task');
  const [dueDate, setDueDate] = useState(task.dueDate || '');
  const [tests, setTests] = useState(task.tests || []);
  const [newTest, setNewTest] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    if (!title.trim()) return;

    onSave({
      ...task,
      title: title.trim(),
      description: description.trim(),
      priority,
      type,
      dueDate,
      tests,
    });
  }

  function addTestCase() {
    if (!newTest.trim()) return;
    setTests((prev) => [
      ...prev,
      { id: Date.now().toString(), label: newTest.trim(), passed: false },
    ]);
    setNewTest('');
  }

  function toggleTest(id) {
    setTests((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, passed: !item.passed } : item
      )
    );
  }

  function removeTest(id) {
    setTests((prev) => prev.filter((item) => item.id !== id));
  }

  return (
    <div className="dialog-overlay" onClick={onClose}>
      <div
        className="dialog-card"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="dialog-header">
          <div>
            <span className="eyebrow">{isExisting ? t('editTask') : t('newTask')}</span>
            <h2 dir="auto">{title || t('untitled')}</h2>
          </div>
          <button
            type="button"
            className="icon-button"
            onClick={onClose}
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="dialog-body">
          <label className="field">
            <span>{t('taskTitle')}</span>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Verify OTP integration"
              required
            />
          </label>

          <label className="field">
            <span>{t('description')}</span>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe acceptance criteria or issue steps..."
            />
          </label>

          <div className="field-grid">
            <label className="field">
              <span>{t('priority')}</span>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
              >
                <option value="High">{t('high')}</option>
                <option value="Medium">{t('medium')}</option>
                <option value="Low">{t('low')}</option>
              </select>
            </label>

            <label className="field">
              <span>{t('type')}</span>
              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
              >
                <option value="task">{t('task')}</option>
                <option value="bug">{t('bug')}</option>
              </select>
            </label>

            <label className="field">
              <span>{t('dueDate')}</span>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </label>
          </div>

          <div className="test-section">
            <div className="test-heading">
              <strong>{t('tests')}</strong>
              <small>{t('testsHint')}</small>
            </div>

            <div className="test-add">
              <input
                type="text"
                value={newTest}
                onChange={(e) => setNewTest(e.target.value)}
                placeholder="Add test case..."
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTestCase();
                  }
                }}
              />
              <button
                type="button"
                className="secondary-button"
                onClick={addTestCase}
              >
                <Plus size={16} />
                {t('add')}
              </button>
            </div>

            <ul className="test-list">
              {tests.map((test) => (
                <li key={test.id} className="test-item">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={test.passed}
                      onChange={() => toggleTest(test.id)}
                    />
                    <span className={test.passed ? 'passed' : ''}>
                      {test.label}
                    </span>
                  </label>

                  <button
                    type="button"
                    className="icon-button text-rose-400"
                    onClick={() => removeTest(test.id)}
                  >
                    <Trash2 size={14} />
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="dialog-actions">
            {isExisting && (
              <button
                type="button"
                className="danger-button"
                onClick={() => onDelete(task.id)}
              >
                <Trash2 size={16} />
                {t('delete')}
              </button>
            )}

            <button
              type="button"
              className="secondary-button"
              onClick={onClose}
            >
              {t('cancel')}
            </button>

            <button type="submit" className="primary-button">
              {t('save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
