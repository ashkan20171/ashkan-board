import { useEffect, useState } from 'react';
import {
  Activity,
  Bug,
  CalendarDays,
  CheckCircle2,
  CircleDot,
  FlaskConical,
  Kanban,
  Plus,
  Search,
  Languages,
} from 'lucide-react';
import TaskDialog from './components/TaskDialog';
import { LanguageProvider, useLanguage } from './i18n';
import {
  canMoveToDone,
  checkIsOverdue,
  columns,
  createTicket,
  loadTickets,
} from './model';

function Card({ task, onOpen }) {
  const { locale, t } = useLanguage();
  const passed = task.tests.filter((x) => x.passed).length;
  const overdue = checkIsOverdue(task);

  const formattedDate = task.dueDate
    ? new Intl.DateTimeFormat(
        locale === 'fa' ? 'fa-IR-u-ca-persian' : 'en-US',
        { day: 'numeric', month: 'short' }
      ).format(new Date(`${task.dueDate}T00:00:00`))
    : null;

  return (
    <article
      className="task-card"
      draggable
      onDragStart={(e) => {
        e.dataTransfer.setData('text/plain', task.id);
        e.dataTransfer.effectAllowed = 'move';
      }}
    >
      <button
        type="button"
        className="task-open"
        onClick={() => onOpen(task)}
      >
        <span className="card-top">
          <span className="task-id" dir="ltr">{task.id}</span>
          <span className={`priority priority-${task.priority.toLowerCase()}`}>
            {t(task.priority.toLowerCase())}
          </span>
        </span>

        <strong dir="auto">{task.title}</strong>

        <span className="card-footer">
          <span className="card-meta">
            {task.type === 'bug' ? (
              <Bug size={14} className="text-rose-400" />
            ) : (
              <CircleDot size={14} className="text-blue-400" />
            )}
            {t(task.type)}
          </span>
          <span className="card-meta">
            <FlaskConical size={14} className="text-purple-300" />
            {passed}/{task.tests.length}
          </span>
        </span>

        {formattedDate && (
          <span className={`due-date ${overdue ? 'is-overdue' : ''}`}>
            <CalendarDays size={13} />
            {overdue && `${t('overdue')} · `}
            {formattedDate}
          </span>
        )}
      </button>
    </article>
  );
}

function MainDashboard() {
  const { locale, setLocale, t } = useLanguage();
  const [tasks, setTasks] = useState(loadTickets);
  const [selectedTask, setSelectedTask] = useState(null);
  const [currentView, setCurrentView] = useState('board');
  const [search, setSearch] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [alertWarning, setAlertWarning] = useState('');

  useEffect(() => {
    try {
      localStorage.setItem('ashkan-board-tickets', JSON.stringify(tasks));
    } catch {
      // storage unavailable fallback
    }
  }, [tasks]);

  const doneCount = tasks.filter((x) => x.status === 'done').length;
  const progressRatio = tasks.length
    ? Math.round((doneCount / tasks.length) * 100)
    : 0;

  const visibleTasks = tasks.filter((task) => {
    const combined = `${task.title} ${task.description} ${task.id}`.toLowerCase();
    const matchesSearch = combined.includes(search.trim().toLowerCase());
    const matchesPriority = priorityFilter === 'all' || task.priority === priorityFilter;
    const matchesView =
      currentView === 'board' ||
      (currentView === 'qa' && task.status === 'qa') ||
      (currentView === 'bugs' && task.type === 'bug');

    return matchesSearch && matchesPriority && matchesView;
  });

  function handleSaveTask(updated) {
    setTasks((current) =>
      current.some((x) => x.id === updated.id)
        ? current.map((x) => (x.id === updated.id ? updated : x))
        : [...current, updated]
    );
    setSelectedTask(null);
    setAlertWarning('');
  }

  function handleMoveTask(id, targetStatus) {
    const item = tasks.find((x) => x.id === id);
    if (!item || item.status === targetStatus) return;

    if (targetStatus === 'done' && !canMoveToDone(item)) {
      setAlertWarning(t('qaGate'));
      return;
    }

    setTasks((current) =>
      current.map((x) => (x.id === id ? { ...x, status: targetStatus } : x))
    );
    setAlertWarning('');
  }

  function openNewTicket(colId = 'backlog') {
    setSelectedTask(createTicket(colId, currentView === 'bugs' ? 'bug' : 'task'));
  }

  const views = [
    { id: 'board', label: 'board', Icon: Kanban },
    { id: 'qa', label: 'qaView', Icon: FlaskConical },
    { id: 'bugs', label: 'bugsView', Icon: Bug },
  ];

  const stats = [
    { label: 'total', val: tasks.length, Icon: Kanban },
    {
      label: 'active',
      val: tasks.filter((x) => x.status === 'in-progress').length,
      Icon: Activity,
    },
    {
      label: 'testing',
      val: tasks.filter((x) => x.status === 'qa').length,
      Icon: FlaskConical,
    },
    { label: 'completed', val: doneCount, Icon: CheckCircle2 },
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand" dir="ltr">
          <span className="brand-icon">A</span>
          <span>AshkanBoard</span>
        </div>

        <div className="sidebar-label">{t('workspace')}</div>

        <nav className="navigation">
          {views.map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              className={`nav-item ${currentView === id ? 'active' : ''}`}
              onClick={() => {
                setCurrentView(id);
                setAlertWarning('');
              }}
            >
              <Icon size={18} />
              {t(label)}
            </button>
          ))}
        </nav>

        <div className="sidebar-note">
          {t('tagline')}
        </div>
      </aside>

      <main className="content">
        <header className="topbar">
          <div className="breadcrumb">
            <span dir="ltr" className="font-semibold text-slate-300">AshkanBoard</span>
            <span>/</span>
            <span>{t(views.find((v) => v.id === currentView).label)}</span>
          </div>

          <button
            type="button"
            className="language-switch"
            onClick={() => setLocale(locale === 'en' ? 'fa' : 'en')}
          >
            <Languages size={16} />
            <span>{locale === 'en' ? 'فارسی' : 'English'}</span>
          </button>
        </header>

        <section className="hero">
          <div>
            <span className="eyebrow">ASHKAN AGILE PLATFORM</span>
            <h1>{t('dashboard')}</h1>
            <p>{t('subtitle')}</p>
          </div>
          <button
            type="button"
            className="primary-button"
            onClick={() => openNewTicket()}
          >
            <Plus size={18} />
            {t('newTask')}
          </button>
        </section>

        <section className="stats">
          {stats.map(({ label, val, Icon }) => (
            <div className="stat-card" key={label}>
              <span className="stat-icon">
                <Icon size={18} />
              </span>
              <strong>{val}</strong>
              <span>{t(label)}</span>
            </div>
          ))}
        </section>

        <section className="progress-panel">
          <div className="progress-heading">
            <div>
              <strong>{t('progress')}</strong>
              <span>
                {tasks.filter(checkIsOverdue).length} {t('overdueCount')}
              </span>
            </div>
            <strong>{progressRatio}% {t('complete')}</strong>
          </div>
          <div
            className="progress-track"
            role="progressbar"
            aria-valuenow={progressRatio}
            aria-valuemin="0"
            aria-valuemax="100"
          >
            <div style={{ width: `${progressRatio}%` }} />
          </div>
        </section>

        <div className="board-toolbar">
          <div>
            <span className="eyebrow">STATUS WORKFLOW</span>
            <h2>{t(views.find((v) => v.id === currentView).label)}</h2>
          </div>

          <div className="filters">
            <label className="search-box">
              <Search size={16} />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t('search')}
              />
            </label>

            <select
              className="priority-filter"
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
            >
              <option value="all">{t('filterPriority')}</option>
              {['High', 'Medium', 'Low'].map((item) => (
                <option key={item} value={item}>
                  {t(item.toLowerCase())}
                </option>
              ))}
            </select>
          </div>
        </div>

        {alertWarning && (
          <div className="notice" role="alert">
            {alertWarning}
          </div>
        )}

        <section className="board">
          {columns.map((column) => {
            const columnTasks = visibleTasks.filter((x) => x.status === column.id);

            return (
              <div
                key={column.id}
                className="board-column"
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  handleMoveTask(e.dataTransfer.getData('text/plain'), column.id);
                }}
              >
                <div className="column-heading">
                  <div>
                    <span className={`status-dot ${column.id}`} />
                    <h3>{t(column.label)}</h3>
                    <span className="column-count">{columnTasks.length}</span>
                  </div>

                  {column.id !== 'done' && (
                    <button
                      type="button"
                      className="icon-button"
                      onClick={() => openNewTicket(column.id)}
                      aria-label={`${t('addTask')} -> ${t(column.label)}`}
                    >
                      <Plus size={16} />
                    </button>
                  )}
                </div>

                <div className="column-body">
                  {columnTasks.length === 0 ? (
                    <div className="empty-state">
                      <p>{t('noTasks')}</p>
                      <small>{t('dropHint')}</small>
                    </div>
                  ) : (
                    columnTasks.map((ticket) => (
                      <Card
                        key={ticket.id}
                        task={ticket}
                        onOpen={setSelectedTask}
                      />
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </section>
      </main>

      {selectedTask && (
        <TaskDialog
          key={selectedTask.id}
          task={selectedTask}
          isExisting={tasks.some((x) => x.id === selectedTask.id)}
          onClose={() => setSelectedTask(null)}
          onSave={handleSaveTask}
          onDelete={(id) => {
            setTasks((curr) => curr.filter((x) => x.id !== id));
            setSelectedTask(null);
          }}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <MainDashboard />
    </LanguageProvider>
  );
}
