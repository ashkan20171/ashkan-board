import { createContext, useContext, useEffect, useState } from 'react';

const translations = {
  en: {
    board: 'Kanban Board',
    qaView: 'QA Pipeline',
    bugsView: 'Bug Tracker',
    workspace: 'WORKSPACE',
    tagline: 'AshkanBoard: Engineering excellence through continuous QA.',
    dashboard: 'Project Dashboard',
    subtitle: 'Plan clearly. Validate rigorously. Ship with confidence.',
    search: 'Search tasks or bugs...',
    filterPriority: 'All Priorities',
    all: 'All',
    total: 'Total Tickets',
    active: 'In Progress',
    testing: 'In QA Review',
    completed: 'Delivered',
    overdueCount: 'Overdue',
    progress: 'Sprint Completion',
    complete: 'completed',
    newTask: 'New Ticket',
    addTask: 'Add Ticket',
    editTask: 'Edit Ticket',
    save: 'Save Changes',
    delete: 'Delete Ticket',
    cancel: 'Cancel',
    title: 'Ticket Title',
    description: 'Description & Scope',
    descriptionHint: 'Add details, user stories or technical background...',
    type: 'Classification',
    task: 'Task / Story',
    bug: 'Defect / Bug',
    priority: 'Priority',
    status: 'State',
    dueDate: 'Target Date',
    optional: 'Optional',
    acceptance: 'QA Gate & Acceptance Criteria',
    testHint: 'Add a verification step (e.g. Unit test passing, API status 200)...',
    add: 'Add Check',
    noTests: 'No verification tests specified yet.',
    tests: 'checks',
    noTasks: 'No tickets in this column.',
    dropHint: 'Drag a card here or open the ticket to advance state.',
    overdue: 'Overdue',
    backlog: 'Backlog',
    todo: 'To Do',
    inProgress: 'In Progress',
    qa: 'Testing / QA',
    done: 'Done',
    high: 'High',
    medium: 'Medium',
    low: 'Low',
    requiredTitle: 'Ticket title cannot be empty.',
    qaGate: 'QA Enforcement: You must have at least one test case and all must pass before moving to Done.',
    confirmDelete: 'Are you sure you want to permanently delete this ticket?',
    close: 'Close',
    removeTest: 'Remove check',
    moveTip: 'Done requires 100% of checks to be verified.',
  },
  fa: {
    board: 'برد کانبان',
    qaView: 'صف تست و کنترل کیفیت',
    bugsView: 'ردیاب باگ‌ها',
    workspace: 'فضای کاری',
    tagline: 'برد اشکان: تضمین کیفیت نرم‌افزار در فرآیند چابک.',
    dashboard: 'داشبورد پروژه',
    subtitle: 'برنامه‌ریزی دقیق، تست مستمر، تحویل بدون باگ.',
    search: 'جست‌وجوی تسک‌ها یا باگ‌ها...',
    filterPriority: 'همه اولویت‌ها',
    all: 'همه',
    total: 'کل تیکت‌ها',
    active: 'در حال توسعه',
    testing: 'در فاز تست (QA)',
    completed: 'تحویل داده‌شده',
    overdueCount: 'دارای تأخیر',
    progress: 'پیشرفت اسپرینت',
    complete: 'تکمیل شده',
    newTask: 'تیکت جدید',
    addTask: 'افزودن تیکت',
    editTask: 'ویرایش تیکت',
    save: 'ذخیره تغییرات',
    delete: 'حذف تیکت',
    cancel: 'انصراف',
    title: 'عنوان تیکت',
    description: 'شرح و محدوده کار',
    descriptionHint: 'جزییات فنی، نیازمندی یا سناریوی ایجاد باگ را بنویسید...',
    type: 'نوع تیکت',
    task: 'تسک / فیچر',
    bug: 'باگ / ایراد نرم‌افزاری',
    priority: 'اولویت',
    status: 'وضعیت',
    dueDate: 'موعد تحویل',
    optional: 'اختیاری',
    acceptance: 'گیت کنترل کیفیت و معیارهای پذیرش (Acceptance)',
    testHint: 'یک مرحله تست بنویسید (مثلاً: تست روی موبایل، پاسخ ۲۰۰ API)...',
    add: 'ثبت تست',
    noTests: 'هنوز تست یا معیار سنجشی تعریف نشده است.',
    tests: 'مورد تست',
    noTasks: 'تیکتی در این ستون نیست.',
    dropHint: 'کارت را اینجا بکشید یا وضعیت آن را ویرایش کنید.',
    overdue: 'تأخیر زمانی',
    backlog: 'بک‌لاگ',
    todo: 'آماده انجام',
    inProgress: 'در حال انجام',
    qa: 'تست و کنترل کیفیت (QA)',
    done: 'انجام‌شده و تایید نهایی',
    high: 'زیاد',
    medium: 'متوسط',
    low: 'کم',
    requiredTitle: 'عنوان تیکت نمی‌تواند خالی باشد.',
    qaGate: 'گیت کیفی فعال است: برای انتقال به حالت انجام‌شده، باید حداقل یک تست ثبت شود و تمامی تست‌ها پاس شوند.',
    confirmDelete: 'آیا از حذف دائم این تیکت مطمئن هستید؟',
    close: 'بستن',
    removeTest: 'حذف مورد تست',
    moveTip: 'انتقال به وضعیت تایید، نیازمند پاس‌شدن ۱۰۰٪ تست‌هاست.',
  },
};

const LanguageContext = createContext(null);

export function LanguageProvider({ children }) {
  const [locale, setLocale] = useState(() => {
    try {
      return localStorage.getItem('ashkan-board-locale') === 'fa' ? 'fa' : 'en';
    } catch {
      return 'en';
    }
  });

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = locale === 'fa' ? 'rtl' : 'ltr';

    try {
      localStorage.setItem('ashkan-board-locale', locale);
    } catch {
      // LocalStorage disabled gracefully
    }
  }, [locale]);

  const t = (key) => translations[locale][key] ?? key;

  return (
    <LanguageContext.Provider value={{ locale, setLocale, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used inside LanguageProvider');
  return context;
}
